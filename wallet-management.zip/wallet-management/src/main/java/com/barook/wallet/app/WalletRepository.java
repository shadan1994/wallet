package com.barook.wallet.app;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * @author Shadan
 */
//@Repository
public interface WalletRepository extends JpaRepository<Wallet, Long> {

//    @Transactional
//    Wallet save(Wallet wallet);
//
//    @Transactional
//    List<Wallet> findByUserId(Long userId);
}