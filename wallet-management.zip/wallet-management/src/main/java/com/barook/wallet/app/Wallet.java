package com.barook.wallet.app;

import javax.persistence.*;

/**
 * @author Shadan
 */
@Entity
@Table(name = "Wallet")
public class Wallet {

    @Id
    @Column(name = "ID")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Balance")
    private Double balance;

    @Column(name = "UserId")
    private Long userId;

    public Wallet() {}

    public Wallet(Long id, Double balance, Long userId) {
        this.id = id;
        this.balance = balance;
        this.userId = userId;
    }

    // getters and setters


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}