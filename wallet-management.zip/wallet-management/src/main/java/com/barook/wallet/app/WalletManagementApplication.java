package com.barook.wallet.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Shadan
 */
@SpringBootApplication
public class WalletManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(WalletManagementApplication.class, args);
    }
}
