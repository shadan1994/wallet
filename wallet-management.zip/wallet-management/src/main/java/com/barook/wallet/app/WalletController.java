package com.barook.wallet.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Shadan
 */
@RestController
public class WalletController {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/add-money/{userId}")
    public String addMoney(@PathVariable("userId") Long userId, @RequestParam(value = "balance") Double balance) {
//       List<Wallet> wallets = walletRepository.findByUserId(userId);
        List<Wallet> wallets = walletRepository.findAll();
        Wallet wallet = wallets.get(0);
        wallet.setBalance(balance + wallet.getBalance());
        wallet.setUserId(userId);
        wallet = walletRepository.save(wallet);
        return "New balance is: " + wallet.getBalance();
    }

    @GetMapping("/get-balance/{userId}")
    public Double getWalletBalance(@PathVariable("userId") Long userId) {
        List<Wallet> wallets = walletRepository.findAll();
        List<User> users = userRepository.findAll();
        return wallets.get(0).getBalance();
    }

}